names = ['Камінь', 'Ножиці', 'Папір']

computer_choice = rand(3)

puts 'введіть ваш варіант: 0 - камінь, 1 - ножиці, 2 - папір'

user_choice = gets.to_i

puts 'Компютер обрав: ' + names[computer_choice]

puts 'Ви обрали: ' + names[user_choice]


if user_choice == computer_choice
  puts 'Нічия'
elsif user_choice == 0 && computer_choice == 1
  puts 'Перемога за вами'
elsif user_choice == 1 && computer_choice == 2
  puts 'Перемога за вами'
elsif user_choice == 2 && computer_choice == 0
  puts 'Перемога за вами'
else
  puts "Переміг комп'ютер"
end# frozen_string_literal: true

